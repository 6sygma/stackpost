<?php
$lang["Facebook pages"] = "Facebook pages";
$lang["Facebook page"] = "Facebook page";
$lang["Success"] = "Success";
$lang["No profile to add"] = "No profile to add";
$lang["Please select a profile to add"] = "Please select a profile to add";
$lang["Add Facebook page"] = "Add Facebook page";
$lang["Facebook"] = "Facebook";
$lang["Add profile"] = "Add profile";
$lang["Choose the profile you'd like to manage"] = "Choose the profile you'd like to manage";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Facebook"] = "Re-connect with Facebook";
$lang["Callback URL:"] = "Callback URL:";
$lang["Permissions"] = "Permissions";