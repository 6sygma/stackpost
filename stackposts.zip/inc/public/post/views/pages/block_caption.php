<div class="caption m-t-15">
	<textarea name="caption" class="form-control post-message" placeholder="<?php _e('Enter your caption')?>"></textarea>
	<div class="caption-toolbar">
		<div class="item">
			<div class="count-word"><i class="fas fa-text-width"></i> <span>0</span></div>			
		</div>
	</div>
</div>