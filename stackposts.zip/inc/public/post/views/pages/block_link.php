<div class="form-group">
	<input type="text" class="form-control" name="link" placeholder="<?php _e('Enter your link')?>">
</div>