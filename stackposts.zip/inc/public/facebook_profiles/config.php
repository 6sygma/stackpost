<?php
return [
    'id' => 'facebook_profiles',
    'name' => 'Facebook profiles',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-facebook-square',
    'color' => '#3b5998'
];