<?php
return [
    'id' => 'facebook_groups',
    'name' => 'Facebook groups',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-facebook-square',
    'color' => '#3b5998'
];