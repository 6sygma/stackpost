<div class="subheader-main"> 
	<button type="button" class="btn btn-label-info m-r-10 subheader-toggle"><i class="fas fa-bars"></i></button>
	<h3 class="title"><i class="<?php _e( $module_icon )?>" style="color: <?php _e( $module_color )?>"></i> <?php _e( $module_name )?></h3>
	<button type="button" class="btn btn-label-info subheader-right-toggle"><i class="far fa-eye"></i></button>
</div>	