<?php
$lang["You are using the monthly payment plan. Cancel it if you want to change the package or change your payment method."] = "You are using the monthly payment plan. Cancel it if you want to change the package or change your payment method.";
$lang["Stripe"] = "Stripe";
$lang["Credit card"] = "Credit card";
$lang["One-Time payment"] = "One-Time payment";
$lang["Stripe one-time payment"] = "Stripe one-time payment";
$lang["Status"] = "Status";
$lang["Enable"] = "Enable";
$lang["Disable"] = "Disable";
$lang["Publishable key"] = "Publishable key";
$lang["Secret key"] = "Secret key";