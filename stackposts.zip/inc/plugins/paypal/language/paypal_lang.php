<?php
$lang["You are using the monthly payment plan. Cancel it if you want to change the package or change your payment method."] = "You are using the monthly payment plan. Cancel it if you want to change the package or change your payment method.";
$lang["Success"] = "Success";
$lang["Paypal"] = "Paypal";
$lang["One-Time payment"] = "One-Time payment";
$lang["Paypal one-time payment"] = "Paypal one-time payment";
$lang["Status"] = "Status";
$lang["Enable"] = "Enable";
$lang["Client ID"] = "Client ID";
$lang["Client secret key"] = "Client secret key";