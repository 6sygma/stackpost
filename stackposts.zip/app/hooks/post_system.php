<?php
/**
 * 
 */
class post_system{
	
	public function action(){
		
	}
}