<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'password');
define('DB_NAME', 'stackposts');
define('TIMEZONE', 'Pacific/Niue');
define('ENCRYPTION_KEY', 'd1c50ac963fa22144ab24ad1235383f8');